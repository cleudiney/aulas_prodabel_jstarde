if(!false) {
  console.log("Passou");
}

var nome = "Matheus";

if(!(nome == "João")) {
  console.log("Ok");
}