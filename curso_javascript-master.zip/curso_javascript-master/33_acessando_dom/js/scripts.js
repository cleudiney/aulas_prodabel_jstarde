// tag
var titulo = document.getElementsByTagName('h1')[0];

console.log(titulo);

var lis = document.getElementsByTagName('li');

console.log(lis);

// id
var paragrafo = document.getElementById('paragrafo');

console.log(paragrafo);

// class
var itensDaLista = document.getElementsByClassName('item');

console.log(itensDaLista);