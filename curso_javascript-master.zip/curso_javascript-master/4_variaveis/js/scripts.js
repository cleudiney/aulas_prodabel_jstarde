var teste = 1;

var nome = "João";

console.log(teste);

teste = 'Matheus';

console.log(teste);

console.log(nome);

var $nome = 'ASD';
var _nome = 'ASD2';

console.log($nome);
console.log(_nome);

var nome5 = 'ASD3';

console.log(nome5);

var meuPrimeiroNome = 'Matheus';

console.log(meuPrimeiroNome); // camelCase

var meusobrenome = "Battisti";

console.log(meusobrenome);

let testando = 1;
const ola = 2;

console.log(testando);
console.log(ola);

var meuNome;

console.log(meuNome);

meuNome = "Matheus";

console.log(meuNome);