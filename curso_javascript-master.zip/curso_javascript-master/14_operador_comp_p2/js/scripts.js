var numero = 4;

if(numero === '5') {
  console.log("O numero é 5");
}

if(numero !== 5) {
  console.log("Não é o número 5 do tipo number");
}