var nome = "Matheus";
var sobrenome = "Battisti";

var nomeCompleto = nome + " " + sobrenome;

console.log(nome);
console.log(typeof nome);

console.log(typeof "asd");

console.log(nomeCompleto);

console.log(typeof "5.292929");

var frase = 'Esta é uma frase complexa';

console.log(frase);
console.log(typeof frase);

console.log(nome + " " + frase);

document.write('Ele disse: "Olá"');

document.write("Ele disse: 'Olá'");

console.log("Este número: " + nome);