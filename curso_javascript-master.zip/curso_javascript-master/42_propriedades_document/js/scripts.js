// propriedades document
console.log(document.body);

console.log(document.head);

console.log(document.links[0]);

document.links[0].textContent = "Twitter";

console.log(document.URL);

console.log(document.title);

document.title = "Aula 42";

console.log(document.title);

