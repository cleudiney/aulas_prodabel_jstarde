var nome = "Xavier";

if(nome == "Pedro") {
  console.log("O nome dele é Pedro");
} else if(nome == "Matheus") {
  console.log("O nome é Matheus");
} else if(nome == "Xavier") {
  console.log("O nome é Xavier");
} else {
  console.log("Ele possui outro nome!");
}

var idade = 19;

if(idade > 20) {
  console.log("Ele pode entrar na festa!");
} else if(idade >= 18) {
  console.log("Ele só pode entrar com autorização");
}

if(nome == "Matheus") {
  console.log("teste");
} else {
  console.log("testando");
}