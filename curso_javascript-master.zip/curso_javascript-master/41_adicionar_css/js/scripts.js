// seleciona elemento
var title = document.querySelector("#title");

// adiciona o estilo
title.style.color = "red";

// background-color
title.style.backgroundColor = "yellow";


// selecionar elemento
var subtitle = document.querySelector(".subtitle");

// adicionar vários estilos
subtitle.style.cssText = "color: blue; background-color: pink; font-size: 50px";