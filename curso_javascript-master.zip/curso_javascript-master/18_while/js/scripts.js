var x = 0;

while(x <= 5) {

  console.log("Testando repetição " + x);

  // incremetador
  x++;

}

var arr = ['teste', 'testando', 'a', 'b'];
var y = 0;

while(y <= 3) {

  console.log(arr[y]);

  y++;

}

var palavra = "Matheus";
var i = 0;

while(i <= 6) {

  console.log(palavra[i]);

  i += 1;

}