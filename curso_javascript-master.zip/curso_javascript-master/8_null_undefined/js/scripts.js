// Hoisting - içamento
console.log(sobrenome);
console.log(numero);

var nome = null;
var sobrenome = "Battisti";

console.log(nome);
console.log(sobrenome);

nome = "Matheus";

console.log(nome);

var numero = 5;