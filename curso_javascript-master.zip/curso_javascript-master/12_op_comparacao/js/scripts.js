var idade = 15;
var possuiCarro = 1;

if(idade >= 18) {
  console.log("O usuário pode fazer a carteira");
}

if(idade <= 17) {
  console.log("O usuário não pode fazer a carteira");
}

if(possuiCarro) {
  console.log("O usuário já pode andar de carro");
}

var nome = "Matheus";

if(nome == "Matheus") {
  console.log("O seu nome é Matheus");
}

if(nome != "Matheus") {
  console.log("O nome não é Matheus");
}

if(20 > 100) {
  console.log("Passou");
}

if(100 < 20) {
  console.log("Passou 2")
}