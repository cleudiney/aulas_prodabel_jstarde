window.onload = function() {

  console.log("Carregou o DOM");

  var title2 = document.querySelector("#title");

  console.log(title2);

}

console.log("Carregou o JS");

var title = document.querySelector("#title");

console.log(title);