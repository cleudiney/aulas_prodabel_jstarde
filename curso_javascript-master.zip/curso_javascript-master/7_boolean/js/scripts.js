var verdadeiro = true;

console.log(verdadeiro);
console.log(typeof verdadeiro);

console.log(typeof true);
console.log(typeof false);

var falso = false;

console.log(falso);
console.log(typeof falso);
