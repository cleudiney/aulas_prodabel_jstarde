console.log("Primeiro");

console.log("Último");

console.log("Mais um console.log");

// Declara uma variável
var a = 1;

a = 'teste';

console.log(a);

// Este é um comentário

/*
  Este
  é
  um
  comentário
  de
  múltiplas
  linhas
*/