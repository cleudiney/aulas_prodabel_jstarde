console.log('Meu nome é "Otávio". Estou aprendendo JavaScript às', 20, 'da noite.');
