const Cachorro = require('../B/C/D/mod');

module.exports = Cachorro;
